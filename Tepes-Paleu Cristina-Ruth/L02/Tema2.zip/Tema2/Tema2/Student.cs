﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tema2
{
    public class Student
    {
        public int Id { get; set; }
        public string Nume_si_prenume { get; set; }
        public string Universitate { get; set; }
   

        public Student() { }
    }
}
